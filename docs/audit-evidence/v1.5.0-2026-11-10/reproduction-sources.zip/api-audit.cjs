const fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),cp=require('node:child_process');
const out=path.resolve('.tools/v150-audit/evidence');fs.mkdirSync(out,{recursive:true});
const base='http://127.0.0.1:18195';const results=[];
const privateFile=path.join(out,'sessions.private.json');
async function req(session,url,method='GET',body,csrf=true,origin=base){
 const r=await fetch(base+'/api/v1'+url,{method,headers:{...(session?{Cookie:session.cookie}:{}),Origin:origin,...(session&&csrf?{'X-CSRF-Token':session.csrfToken}:{}),'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});
 const text=await r.text();let data;try{data=JSON.parse(text)}catch{data=text}
 return {status:r.status,data,cookie:r.headers.get('set-cookie')?.split(';')[0]};
}
function check(name,ok,detail){results.push({name,result:ok?'PASS':'FAIL',detail});console.log((ok?'PASS ':'FAIL ')+name+(detail?' '+JSON.stringify(detail):''));}
async function main(){
 let state;
 if(fs.existsSync(privateFile)){state=JSON.parse(fs.readFileSync(privateFile));}
 else{
  const token=cp.execFileSync('C:/Program Files/Git/bin/bash.exe',['C:/Users/luanf/.qui-local/r.sh','cat /root/qui-audit/20261110-0b60eca/live/setup-token'],{encoding:'utf8'}).trim();
  const password='Audit!'+crypto.randomBytes(18).toString('hex');
  const setup=await req(null,'/auth/setup','POST',{token,username:'audit-owner',password,platformName:'v1.5.0 隔离审计',timezone:'UTC'});
  if(setup.status!==201)throw Error('setup status '+setup.status);
  const owner={cookie:setup.cookie,csrfToken:setup.data.csrfToken};
  const admin=await req(owner,'/admins','POST',{username:'audit-viewer',displayName:'Audit Viewer',password,role:'Viewer'});
  if(admin.status!==201)throw Error('viewer setup status '+admin.status);
  const login=await req(null,'/auth/login','POST',{username:'audit-viewer',password});
  if(login.status!==200)throw Error('viewer login status '+login.status);
  const viewer={cookie:login.cookie,csrfToken:login.data.csrfToken};
  state={owner,viewer,password};fs.writeFileSync(privateFile,JSON.stringify(state),{mode:0o600});
 }
 const {owner,viewer}=state;
 const owners=['/notification-rules','/notification-channels','/agent-releases','/system/tuning-auto-apply','/nodes/audit-none/certificate-matches?domain=example.com','/service-sets','/agent-updates'];
 for(const url of owners){const a=await req(null,url),v=await req(viewer,url);check('auth '+url,a.status===401&&v.status===403,{anonymous:a.status,viewer:v.status});}
 const writes=[['POST','/notification-channels'],['PUT','/notification-rules'],['POST','/notifications/read-all'],['POST','/nodes/audit-none/tuning/recommendations/dismiss'],['PUT','/system/tuning-auto-apply'],['POST','/agent-releases/9.9.9/import'],['POST','/agent-updates'],['POST','/service-sets']];
 for(const [method,url] of writes){const no=await req(owner,url,method,{},false),cross=await req(owner,url,method,{},true,'https://cross.example.invalid');check('csrf '+method+' '+url,no.status===403&&cross.status===403,{missing:no.status,crossOrigin:cross.status});}
 const center=await req(viewer,'/notifications');check('Viewer notification center',center.status===200);
 const channel=await req(owner,'/notification-channels','POST',{kind:'telegram',name:'Audit disabled channel',enabled:false,config:{botToken:'AUDIT_ONLY_SECRET_1234',chatId:'audit-chat'}});
 check('channel credentials masked',channel.status===201&&!JSON.stringify(channel.data).includes('AUDIT_ONLY_SECRET_1234'),{status:channel.status,last4:channel.data.last4});
 const node=await req(owner,'/nodes/enrollment-token','POST',{name:'Audit Linux fixture',connectHost:'audit.example.com'});
 if(node.status!==201)throw Error('node status '+node.status);
 state.nodeId=node.data.node.id;
 check('enrollment connectHost stored',node.data.node.connectHost==='audit.example.com');
 const user=await req(owner,'/users','POST',{username:'audit-user-'+Date.now(),displayName:'Audit User',status:'active',allowedProtocols:['http'],deviceLimit:0,trafficLimit:0});
 check('legacy allowedProtocols normalized',user.status===201&&user.data.allowedProtocols?.length===8,{status:user.status,protocols:user.data.allowedProtocols?.length});
 const svc=state.serviceId?await req(owner,'/service-sets/'+state.serviceId):await req(owner,'/service-sets','POST',{name:'Audit OpenAI source',enabled:true,domains:[],suffixes:[],keywords:[],cidrs:[],sources:[{url:'https://raw.githubusercontent.com/blackmatrix7/ios_rule_script/master/rule/Clash/OpenAI/OpenAI.list',format:'text',behavior:'classical',intervalSeconds:3600}]});
 check('create/read external rule source',[200,201].includes(svc.status),{status:svc.status});
 if([200,201].includes(svc.status)){state.serviceId=svc.data.id;state.sourceId=svc.data.sources?.[0]?.id; if(state.sourceId){const refreshed=await req(owner,`/service-sets/${state.serviceId}/sources/${state.sourceId}/refresh`,'POST',{});check('real HTTPS source refresh',refreshed.status===200&&refreshed.data.lastStatus==='ok',{status:refreshed.status,lastStatus:refreshed.data.lastStatus,entryCount:refreshed.data.entryCount,error:refreshed.data.lastErrorCode});}}
 for(const name of ['../configuration.key','artifacts/abc.bin','proxy-agent/linux/amd64/1/manifest.json']){const r=await fetch(base+'/agent-catalogue/'+name);check('catalogue path refusal '+name,r.status===404,{status:r.status});}
 fs.writeFileSync(privateFile,JSON.stringify(state),{mode:0o600});
 fs.writeFileSync(path.join(out,'api-audit.json'),JSON.stringify({snapshot:'0b60eca',base,checks:results},null,2));
 console.log('SUMMARY '+JSON.stringify({checks:results.length,pass:results.filter(r=>r.result==='PASS').length,fail:results.filter(r=>r.result==='FAIL').length}));
}
main().catch(e=>{console.error(e.message);process.exitCode=1});
