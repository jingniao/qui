package backup

import (
 "context"
 "path/filepath"
 "testing"
 "proxycontrol/internal/panel/policy"
)

func TestAuditRejectUndecryptableRuleCache(t *testing.T) {
 source,dir,_:=sourceFixture(t)
 ctx:=context.Background()
 repo:=&policy.Repository{Database:source.Database,Vault:source.ConfigurationVault}
 svc,err:=repo.SaveService(ctx,"",policy.ServiceInput{Name:"Audit cache",Enabled:true,Domains:[]string{"example.com"}})
 if err!=nil{t.Fatal(err)}
 if err=repo.SaveSources(ctx,nil,svc.ID,[]policy.SourceInput{{ID:"audit-cache",URL:"https://example.com/rules",Format:"text",Behavior:"domain"}});err!=nil{t.Fatal(err)}
 _,err=source.Database.Exec("UPDATE service_set_sources SET encrypted_cache=X'010203040506',last_status='ok',entry_count=1 WHERE id='audit-cache'")
 if err!=nil{t.Fatal(err)}
 result,err:=source.Create(ctx,dir,"audit_cache_corrupt_001","owner",testPassword)
 if err!=nil{t.Logf("create correctly rejected corrupt cache: %v",err);return}
 _,err=Inspect(ctx,dir,filepath.Join(dir,result.Manifest.ID+".pcb"),testPassword)
 if err==nil{t.Fatal("AUDIT DEFECT: complete encrypted archive inspection accepted undecryptable service_set_sources.encrypted_cache")}
}

func TestAuditRejectUnknownTuningDismissal(t *testing.T) {
 source,dir,_:=sourceFixture(t)
 ctx:=context.Background()
 var nodeID string
 if err:=source.Database.QueryRow("SELECT id FROM nodes LIMIT 1").Scan(&nodeID);err!=nil{t.Fatal(err)}
 _,err:=source.Database.Exec("INSERT INTO node_tuning_dismissals(node_id,key,value,rules_version,dismissed_at) VALUES(?,'kernel.arbitrary_unknown','not-a-setting','2026.11-1','2026-11-10T00:00:00Z')",nodeID)
 if err!=nil{t.Fatal(err)}
 result,err:=source.Create(ctx,dir,"audit_dismiss_corrupt_001","owner",testPassword)
 if err!=nil{t.Logf("create correctly rejected unknown dismissal: %v",err);return}
 _,err=Inspect(ctx,dir,filepath.Join(dir,result.Manifest.ID+".pcb"),testPassword)
 if err==nil{t.Fatal("AUDIT DEFECT: archive inspection accepted non-whitelisted tuning dismissal key")}
}
