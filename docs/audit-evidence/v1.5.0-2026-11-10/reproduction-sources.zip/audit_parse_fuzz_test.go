package policy
import("net/netip";"testing";shared "proxycontrol/pkg/contracts/policy")
func FuzzAuditRuleList(f *testing.F){
 f.Add([]byte("DOMAIN,example.com\nDOMAIN-SUFFIX,example.org\nDOMAIN-KEYWORD,openai\nIP-CIDR,10.0.0.0/8\n"),"text","classical")
 f.Add([]byte("payload:\n - '+.example.com'\n - '*.example.org'\n"),"yaml","domain")
 f.Add([]byte("payload: [192.0.2.0/24, '2001:db8::/32']"),"yaml","ipcidr")
 f.Fuzz(func(t *testing.T,b []byte,format,behavior string){
  if len(b)>2<<20{t.Skip()}
  p,_,err:=ParseRuleList(b,format,behavior);if err!=nil{return}
  if len(p.Domains)+len(p.Suffixes)+len(p.Keywords)+len(p.CIDRs)>MaxSourceEntries{t.Fatal("too many parsed entries")}
  for _,s:=range append(p.Domains,p.Suffixes...){if _,err:=shared.Domain(s,false);err!=nil{t.Fatal("invalid parsed domain",s)}}
  for _,s:=range p.Keywords{if _,err:=shared.Keyword(s);err!=nil{t.Fatal("invalid parsed keyword",s)}}
  for _,s:=range p.CIDRs{if _,err:=netip.ParsePrefix(s);err!=nil{if _,err:=netip.ParseAddr(s);err!=nil{t.Fatal("invalid parsed CIDR",s)}}}
 })
}
