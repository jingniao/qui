package deployment

import (
 "context"
 "encoding/base64"
 "fmt"
 "net/http/httptest"
 "testing"
 "proxycontrol/pkg/contracts/release"
)

func TestAuditRejectSignedReleaseVersionMismatch(t *testing.T) {
 pub,priv:=generateSigningKey(t)
 binary:=[]byte("signed old agent binary")
 manifest,_:=createSignedAgentAsset(t,"1.4.6","amd64",1004006,priv,binary)
 fake:=&fakeGitHub{lists:map[string]string{"jingniao/qui":`[{"tag_name":"v1.5.0","assets":[{"name":"proxy-agent-1.5.0-linux-amd64.bin","browser_download_url":"/download/agent.bin"},{"name":"proxy-agent-1.5.0-linux-amd64.manifest.json","browser_download_url":"/download/manifest.json"}]}]`},files:map[string]string{"/download/agent.bin":string(binary),"/download/manifest.json":manifest}}
 host:=httptest.NewServer(fake);defer host.Close()
 svc:=&AgentReleases{Directory:t.TempDir(),Store:&fakeAgentReleaseStore{},Keys:[]release.KeyPin{{PublicKey:base64.StdEncoding.EncodeToString(pub),Components:[]string{"proxy-agent"}}},Client:host.Client(),API:host.URL+"/repos/jingniao/qui"}
 entries,err:=svc.Import(context.Background(),"1.5.0","audit","127.0.0.1")
 if err==nil{got:="";if len(entries)>0{got=fmt.Sprintf("%s sequence=%d",entries[0].Signed.Manifest.Version,entries[0].Signed.Manifest.Sequence)};t.Fatalf("AUDIT DEFECT: requested 1.5.0 but imported %s",got)}
}
