const {chromium}=require('../browser-runner/node_modules/playwright-core');
const fs=require('node:fs'),path=require('node:path');
const out=path.resolve('.tools/v150-audit/evidence');
const state=JSON.parse(fs.readFileSync(path.join(out,'sessions.private.json')));
const base='http://127.0.0.1:18195',results=[],errors=[];
function record(name,ok,detail){const x={name,result:ok?'PASS':'FAIL',detail};results.push(x);console.log(x.result+' '+name+' '+JSON.stringify(detail??{}));}
async function api(url,method='GET',body,session=state.owner){const r=await fetch(base+'/api/v1'+url,{method,headers:{Cookie:session.cookie,Origin:base,'X-CSRF-Token':session.csrfToken,'Content-Type':'application/json'},body:body===undefined?undefined:JSON.stringify(body)});return{status:r.status,data:await r.json()};}
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe',args:['--no-first-run','--disable-default-apps']});
 try{
 const context=await browser.newContext({viewport:{width:1600,height:1100}});
 await context.addCookies([{name:'proxy_session',value:state.owner.cookie.split('=')[1],url:base,httpOnly:true,sameSite:'Strict'}]);
 const page=await context.newPage();page.setDefaultTimeout(12000);page.on('pageerror',e=>errors.push(e.message));
 await page.goto(base+'/nodes/'+state.nodeId+'?tab=tuning');
 await page.getByRole('heading',{name:'调优状态',exact:true}).waitFor();
 await page.getByRole('heading',{name:'白名单参数',exact:true}).waitFor();
 const ramRow=page.locator('tr').filter({has:page.locator('div.font-mono').filter({hasText:/^net\.ipv4\.tcp_rmem$/})});
 record('satisfied vector displayed as managed',!(await ramRow.innerText()).includes('偏离/漂移'),{text:(await ramRow.innerText()).replace(/\s+/g,' ').slice(0,220)});
 const fd=await page.getByText('Agent 文件句柄 (软/硬)',{exact:true}).locator('..').innerText();
 record('fd limits displayed from real API fields',fd.includes('524287'),{text:fd});
 const readOnlyRow=page.locator('tr').filter({has:page.locator('div.font-mono').filter({hasText:/^net\.core\.rmem_max$/})});
 record('reported read-only key disabled',await readOnlyRow.locator('input').isDisabled());
 await page.screenshot({path:path.join(out,'ui-tuning-status.png'),fullPage:true});
 await page.getByRole('button',{name:'纳入面板管理',exact:true}).click();
 const wmemRow=page.locator('tr').filter({has:page.locator('div.font-mono').filter({hasText:/^net\.ipv4\.tcp_wmem$/})});
 const adopted=await wmemRow.locator('input').inputValue();
 await page.getByRole('button',{name:'一键应用',exact:true}).click();
 await page.getByText(/参数超出允许范围/).first().waitFor({timeout:1500}).catch(()=>{});
 const body=await page.locator('body').innerText();
 const errorsInBody=body.match(/参数超出允许范围[^\n]*/g)||[];
 record('adopted external TCP buffer can be confirmed',errorsInBody.length===0&&await page.getByText('确认应用调优？',{exact:true}).count()>0,{adoptedValue:adopted,validationErrors:errorsInBody});
 await page.screenshot({path:path.join(out,'ui-tuning-adopt-error.png'),fullPage:true});
 const policy=await api('/policies','POST',{name:'Audit external block '+Date.now(),priority:1,enabled:true,scope:{node_ids:[state.nodeId]},match:{service_ids:[state.serviceId]},action:{type:'Block',failover:'Block'},timezone:'UTC',remark:'isolated audit'});
 record('policy creation accepted',policy.status===201,{status:policy.status});
 if(policy.status===201){const sim=await api('/policies/simulate','POST',{nodeId:state.nodeId,domain:'chatgpt.com',port:443,network:'tcp',time:new Date().toISOString()});record('fetched external source actually blocks in simulator',sim.status===200&&sim.data.matched&&sim.data.action?.type==='Block',{status:sim.status,matched:sim.data.matched,action:sim.data.action?.type,reason:sim.data.reason});}
 const viewerCenter=await api('/notifications','GET',undefined,state.viewer);
 record('Viewer sees node alerts but not system alerts',viewerCenter.status===200&&viewerCenter.data.items.some(x=>x.title==='AUDIT CPU visible to Viewer')&&!viewerCenter.data.items.some(x=>x.title==='AUDIT system alert Owner only'));
 const vcontext=await browser.newContext({viewport:{width:390,height:844}});
 await vcontext.addCookies([{name:'proxy_session',value:state.viewer.cookie.split('=')[1],url:base,httpOnly:true,sameSite:'Strict'}]);
 const vp=await vcontext.newPage();vp.on('pageerror',e=>errors.push(e.message));
 await vp.goto(base+'/nodes/'+state.nodeId+'?tab=tuning');await vp.getByRole('heading',{name:'调优状态',exact:true}).waitFor();
 record('Viewer UI has no apply control',await vp.getByRole('button',{name:'一键应用',exact:true}).count()===0);
 await vp.screenshot({path:path.join(out,'ui-viewer-mobile.png'),fullPage:true});
 record('browser page errors absent',errors.length===0,{errors});
 }finally{await browser.close();fs.writeFileSync(path.join(out,'browser-audit.json'),JSON.stringify({snapshot:'0b60eca',fixture:'synthetic HostInfo/heartbeat in isolated Linux panel DB; no live Agent',results},null,2));}
})().catch(e=>{console.error('HARNESS_ERROR '+e.message);process.exitCode=1});
