#!/usr/bin/env bash
set -euo pipefail
r="$HOME/.qui-local/r.sh"
a=/root/qui-audit/20261110-0b60eca
"$r" "cat > $a/probe-src/.tools/cache-inspect.go" < .tools/v150-audit/cache-inspect.go
"$r" "cd $a/probe-src && . /root/qui-env.sh && go run ./.tools/cache-inspect.go | tee $a/evidence/real-cache-inspect.log" < .tools/v150-audit/evidence/fixture-public.json
