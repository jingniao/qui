const fs=require('fs'),ts=require('../../web/node_modules/typescript'),vm=require('vm');
const source=fs.readFileSync('web/src/modules/proxy/components/node-editor/NodeProtocolFields.vue','utf8').split('<script setup lang="ts">')[1].split('</script>')[0];
const ast=ts.createSourceFile('component.ts',source,ts.ScriptTarget.Latest,true);
const functions=ast.statements.filter(n=>ts.isFunctionDeclaration(n)&&['findCertificates','requestCertificate'].includes(n.name?.text)).map(n=>n.getText(ast)).join('\n');
const code=ts.transpileModule(functions,{compilerOptions:{target:ts.ScriptTarget.ES2020}}).outputText;
let finishLookup,poll;
const ctx={lookupTimer:undefined,pollTimer:undefined,lookupDomain:{value:'a.example.com'},f:{value:{nodeId:'node-a',certificateId:''}},matches:{value:null},choiceKey:{value:''},lookupError:{value:''},lookupBusy:{value:false},requestStatus:{value:''},clearTimeout(){},clearInterval(){},setInterval(fn){poll=fn;return 1},findCertificateMatches(){return new Promise(resolve=>{finishLookup=resolve})},certificatesAPI:{create:async()=>({id:'cert-a'}),list:async()=>[{id:'cert-a',status:'valid'}]},applyCertificateChoice(form,choice){form.certificateId=choice.certificateId}};
vm.createContext(ctx);vm.runInContext(code,ctx);
(async()=>{
 const request=ctx.findCertificates();ctx.lookupDomain.value='b.example.com';ctx.matches.value=null;finishLookup({domain:'a.example.com',nodeFiles:[],library:[]});await request;
 const lookup={currentDomain:ctx.lookupDomain.value,displayedMatchesDomain:ctx.matches.value.domain};
 ctx.lookupDomain.value='a.example.com';await ctx.requestCertificate();ctx.lookupDomain.value='b.example.com';await poll();
 const issuance={currentDomain:ctx.lookupDomain.value,selectedCertificateId:ctx.f.value.certificateId,status:ctx.requestStatus.value};
 const result={snapshot:'0b60eca',probe:'actual SFC async functions transpiled with injected network/timer boundaries',lookup,issuance};
 fs.writeFileSync('.tools/v150-audit/evidence/certificate-async.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
})().catch(e=>{console.error(e.message);process.exitCode=1});
