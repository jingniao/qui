#!/usr/bin/env bash
set -euo pipefail
"$HOME/.qui-local/r.sh" 'a=/root/qui-audit/20261110-0b60eca; cd "$a/src"; . /root/qui-env.sh; npm --prefix web audit --omit=dev --json > "$a/evidence/npm-audit-production.json"; echo $? > "$a/evidence/npm-audit-production.exit"; go run golang.org/x/vuln/cmd/govulncheck@v1.1.4 -json ./cmd/panel ./cmd/agent > "$a/evidence/govulncheck-binaries.json" 2> "$a/evidence/govulncheck-binaries.stderr"; echo $? > "$a/evidence/govulncheck-binaries.exit"; printf "EXTRA_SCAN_DONE\n"'
