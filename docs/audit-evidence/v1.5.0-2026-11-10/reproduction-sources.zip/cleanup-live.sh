#!/usr/bin/env bash
set -euo pipefail
a=/root/qui-audit/20261110-0b60eca
if [[ -f $a/live/panel.pid ]];then
 pid=$(cat "$a/live/panel.pid")
 if kill -0 "$pid" 2>/dev/null;then
  target=$(readlink -f "/proc/$pid/exe")
  [[ $target == "$a/bin/proxy-panel" ]] || { echo 'REFUSE: process ownership mismatch';exit 1; }
  kill -TERM "$pid"
  for n in $(seq 1 40);do
   kill -0 "$pid" 2>/dev/null || break
   [[ -s /proc/$pid/cmdline ]] || break
   sleep 0.25
  done
 fi
fi
if ss -ltn | grep -qE ':2295[01] ';then echo 'REFUSE: isolated listener remains';exit 1;fi
[[ $(readlink -f "$a/live") == "$a/live" ]] || { echo 'REFUSE: live directory changed';exit 1; }
rm -rf -- "$a/live"
{
 date -u +%FT%TZ
 printf 'ISOLATED_PANEL_STOPPED_AND_TEST_DB_REMOVED\n'
 printf 'ORIGINAL_SERVICES\n'
 systemctl is-active proxy-panel proxy-agent proxy-agent-host-network.path proxy-agent-tuning.path || true
 printf 'HOST_NETWORK_TABLES\n'
 nft list tables
 printf 'HOST_SYSCTLS\n'
 sysctl net.ipv4.tcp_congestion_control net.core.default_qdisc
 printf 'ORIGINAL_CONFIG_HASHES\n'
 sha256sum /etc/sysctl.d/99-proxy-tuning.conf /var/lib/proxy-agent/tuning/desired.json /var/lib/proxy-agent/host-network/desired.json 2>/dev/null || true
 printf 'AUDIT_NETWORK_NAMESPACES\n'
 ip netns list | grep qui-audit || true
 printf 'AUDIT_UNITS\n'
 systemctl list-units --all --no-legend | grep qui-audit || true
 printf 'AUDIT_BINARY_DIRS\n'
 find /usr/local/lib -maxdepth 1 -type d -name 'qui-audit-v150-*' -print
} > "$a/evidence/cleanup.log"
cat "$a/evidence/cleanup.log"
