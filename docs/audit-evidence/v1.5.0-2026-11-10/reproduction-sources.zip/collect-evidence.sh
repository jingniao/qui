#!/usr/bin/env bash
set -euo pipefail
mkdir -p .tools/v150-audit/evidence/linux
"$HOME/.qui-local/r.sh" 'cd /root/qui-audit/20261110-0b60eca/evidence && find . -maxdepth 1 -type f \( -name "*.log" -o -name "*.exit" -o -name "*.json" -o -name "*.csv" -o -name "baseline.txt" \) -print0 | tar --null -T - -cf -' | tar -xf - -C .tools/v150-audit/evidence/linux
printf 'EVIDENCE_COLLECTED\n'
