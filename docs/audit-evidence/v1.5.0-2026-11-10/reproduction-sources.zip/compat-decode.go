package main
import("bytes";"encoding/json";"fmt";"os";"path/filepath";d "proxycontrol/pkg/contracts/desiredstate")
func main(){for _,name:=range []string{"disabled-hop","disabled-keyword"}{b,e:=os.ReadFile(filepath.Join(os.Args[1],name+".json"));if e!=nil{panic(e)};var state d.State;dec:=json.NewDecoder(bytes.NewReader(b));dec.DisallowUnknownFields();e=dec.Decode(&state);fmt.Printf("v1.4.7_strict_decode_%s=%v\n",name,e)}}
