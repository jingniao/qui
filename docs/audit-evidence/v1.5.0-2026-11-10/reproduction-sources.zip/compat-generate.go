package main
import("encoding/json";"fmt";"os";"path/filepath";d "proxycontrol/pkg/contracts/desiredstate")
func main(){
 root:=os.Args[1]
 base:=d.State{SchemaVersion:1,Revision:1,NodeID:"audit-node",Logging:d.Logging{DomainOnly:true},Outbounds:[]d.Outbound{{ID:"direct",Protocol:"direct",Enabled:true}}}
 hop:=base
 hop.Inbounds=[]d.Inbound{{ID:"hop",Core:"sing-box",Protocol:"hysteria2",Listen:"0.0.0.0",Port:8443,Enabled:false,DefaultOutbound:"direct",Settings:d.ProtocolSettings{Transport:"quic",Security:"tls",CertificatePath:d.CertificateDirectory+"/a.crt",PrivateKeyPath:d.CertificateDirectory+"/a.key",QUIC:&d.QUICSettings{HopPortStart:20000,HopPortEnd:20010,HopIntervalSeconds:30}}}}
 keyword:=base
 keyword.Policies=[]d.Policy{{ID:"keyword",Name:"disabled keyword",Enabled:false,Match:d.Match{Keywords:[]string{"openai"}},Action:d.Action{Type:"Block",Failover:"Block"},Timezone:"UTC"}}
 fmt.Printf("disabled_hop_capability_error=%v\n",d.RequirePortHopSupport(hop,false))
 fmt.Printf("disabled_keyword_capability_error=%v\n",d.RequireKeywordSupport(keyword,[]d.CoreKeywordCapability{{Name:"sing-box",DomainKeywordSupported:false}}))
 for name,state:=range map[string]d.State{"disabled-hop":hop,"disabled-keyword":keyword}{
  b,e:=json.Marshal(state);if e!=nil{panic(e)}
  _,e=d.Decode(b);fmt.Printf("current_decode_%s=%v\n",name,e);if e!=nil{panic(e)}
  if e=os.WriteFile(filepath.Join(root,name+".json"),b,0600);e!=nil{panic(e)}
 }
}
