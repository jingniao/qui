#!/usr/bin/env bash
set -euo pipefail
"$HOME/.qui-local/r.sh" 'for pid in $(pgrep -x go);do cmd=$(tr "\000" " " < /proc/$pid/cmdline);case "$cmd" in "go test -v -p 4 -count=1 -timeout 60m"*) log=$(readlink /proc/$pid/fd/1); printf "CORE_GO pid=%s log=%s\n" "$pid" "$log"; case "$log" in /tmp/*) tail -n 12 "$log";; esac;;esac;done; ps -eo pid,ppid,etimes,pcpu,comm | grep -E "server.test|backup.test|recovery.test|singbox.test|xray.test|deployment.test"'
