#!/usr/bin/env bash
set -uo pipefail
a=/root/qui-audit/20261110-0b60eca
. /root/qui-env.sh
cd "$a/probe-src" || exit 1
go test -run '^$' -fuzz '^FuzzAuditRuleList$' -fuzztime 20s -parallel 2 -timeout 2m ./internal/panel/policy > "$a/evidence/fuzz-rules.log" 2>&1
echo $? > "$a/evidence/fuzz-rules.exit"
cd "$a/src" || exit 1
GOOS=linux GOARCH=arm64 CGO_ENABLED=0 go build -trimpath -o "$a/bin/panel-arm64" ./cmd/panel > "$a/evidence/cross-arm64.log" 2>&1
panel_code=$?
GOOS=linux GOARCH=arm64 CGO_ENABLED=0 go build -trimpath -o "$a/bin/agent-arm64" ./cmd/agent >> "$a/evidence/cross-arm64.log" 2>&1
agent_code=$?
printf 'panel=%s agent=%s\n' "$panel_code" "$agent_code" >> "$a/evidence/cross-arm64.log"
printf '%s %s\n' "$panel_code" "$agent_code" > "$a/evidence/cross-arm64.exit"
file "$a/bin/panel-arm64" "$a/bin/agent-arm64" >> "$a/evidence/cross-arm64.log"
