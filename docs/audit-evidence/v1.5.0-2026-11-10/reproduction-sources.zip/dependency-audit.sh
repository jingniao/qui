#!/usr/bin/env bash
set -uo pipefail
a=/root/qui-audit/20261110-0b60eca
cd "$a/src" || exit 1
. /root/qui-env.sh
npm --prefix web audit --json > "$a/evidence/npm-audit.json" 2> "$a/evidence/npm-audit.stderr"
echo $? > "$a/evidence/npm-audit.exit"
go run golang.org/x/vuln/cmd/govulncheck@v1.1.4 -json ./... > "$a/evidence/govulncheck.json" 2> "$a/evidence/govulncheck.stderr"
echo $? > "$a/evidence/govulncheck.exit"
