#!/usr/bin/env bash
set -euo pipefail
"$HOME/.qui-local/r.sh" 'a=/root/qui-audit/20261110-0b60eca/evidence; date -u +%FT%TZ; cat "$a/runner.log"; printf "CHECK\n"; tail -n 5 "$a/check.log"; printf "HY2\n"; test ! -f "$a/hy2.exit" || cat "$a/hy2.exit"; tail -n 6 "$a/hy2.log" 2>/dev/null; printf "VULN\n"; for p in npm-audit govulncheck;do printf "%s " "$p"; cat "$a/$p.exit" 2>/dev/null || true; done; tail -n 4 "$a/govulncheck.stderr" 2>/dev/null; printf "PROCESSES\n"; ps -eo pid,etimes,pcpu,rss,comm,args | grep -E "qui-audit|go test -race|govulncheck|hy2-test" | grep -v grep'
