#!/usr/bin/env bash
set -uo pipefail
audit=/root/qui-audit/20261110-0b60eca
cd "$audit/src" || exit 1
. /root/qui-env.sh
mkdir -p "$audit/evidence/check-temp"
export QUI_GATE_SCOPE=full RUNNER_TEMP="$audit/evidence/check-temp"
start=$SECONDS
printf 'AUDIT START %s SHA=0b60eca7b3c57f72a8ddd7c1b6a86eafb95940eb\n' "$(date -u +%FT%TZ)"
go version
node --version
npm --version
printf 'CORES\n'
"$XRAY_BINARY" version | head -n 1
"$SINGBOX_BINARY" version | head -n 2
"$MIHOMO_BINARY" -v | head -n 1
"$GOST_BINARY" -V
part() {
  name=$1; shift
  printf 'PART %s START %s\n' "$name" "$(date -u +%FT%TZ)"
  "$@" > "$audit/evidence/$name.log" 2>&1
  status=$?
  printf '%s\n' "$status" > "$audit/evidence/$name.exit"
  printf 'PART %s EXIT=%s %s\n' "$name" "$status" "$(date -u +%FT%TZ)"
}
part check bash scripts/check.sh
part cores bash scripts/ci-real-core-test.sh -p 4 -count=1 -timeout 60m $(bash scripts/real-core-packages.sh)
part signing bash deploy/linux/tests/sign-agent-release-test.sh
printf 'AUDIT END %s elapsed=%ss\n' "$(date -u +%FT%TZ)" "$((SECONDS-start))"
