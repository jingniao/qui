#!/usr/bin/env bash
set -euo pipefail
a=/root/qui-audit/20261110-0b60eca
work="$a/live/hy2"
mkdir -p "$work"
srv=qui-audit-srv-$$
cli=qui-audit-cli-$$
v1=qas$$
v2=qac$$
root=$(mktemp -d /run/qui-audit-v150-XXXXXX)
bin_dir=$(mktemp -d /usr/local/lib/qui-audit-v150-XXXXXX)
cleanup(){
 set +e
 for ns in "$srv" "$cli";do
  for pid in $(ip netns pids "$ns" 2>/dev/null);do kill "$pid" 2>/dev/null;done
  ip netns delete "$ns" 2>/dev/null
 done
 ip link delete "$v1" 2>/dev/null
 [[ $root == /run/qui-audit-v150-* ]] && rm -rf -- "$root"
 [[ $bin_dir == /usr/local/lib/qui-audit-v150-* ]] && rm -rf -- "$bin_dir"
}
trap cleanup EXIT
. /root/qui-env.sh
cd "$a/probe-src"
go build -o "$bin_dir/helper" ./.tools/linux-helper-probe.go
ip netns add "$srv"
ip netns add "$cli"
ip link add "$v1" type veth peer name "$v2"
ip link set "$v1" netns "$srv"
ip link set "$v2" netns "$cli"
ip -n "$srv" addr add 172.30.195.1/30 dev "$v1"
ip -n "$cli" addr add 172.30.195.2/30 dev "$v2"
ip -n "$srv" link set lo up
ip -n "$cli" link set lo up
ip -n "$srv" link set "$v1" up
ip -n "$cli" link set "$v2" up
openssl req -x509 -newkey rsa:2048 -nodes -days 1 -subj '/CN=audit.invalid' -keyout "$work/key.pem" -out "$work/cert.pem" >/dev/null 2>&1
chmod 0600 "$work/key.pem"
cat > "$work/server.json" <<EOF
{"log":{"level":"warn"},"inbounds":[{"type":"hysteria2","tag":"hy2","listen":"0.0.0.0","listen_port":8443,"users":[{"password":"audit-only-hy2"}],"tls":{"enabled":true,"certificate_path":"$work/cert.pem","key_path":"$work/key.pem"}}],"outbounds":[{"type":"direct"}]}
EOF
cat > "$work/client.json" <<EOF
{"log":{"level":"warn"},"inbounds":[{"type":"socks","listen":"127.0.0.1","listen_port":19080}],"outbounds":[{"type":"hysteria2","server":"172.30.195.1","server_ports":["20000:20010"],"hop_interval":"10s","password":"audit-only-hy2","tls":{"enabled":true,"server_name":"audit.invalid","insecure":true}}]}
EOF
cat > "$work/mihomo.yaml" <<EOF
socks-port: 19081
mode: rule
log-level: warning
proxies:
  - name: hop
    type: hysteria2
    server: 172.30.195.1
    port: 8443
    ports: 20000-20010
    hop-interval: 10
    password: audit-only-hy2
    sni: audit.invalid
    skip-cert-verify: true
rules:
  - MATCH,hop
EOF
"$SINGBOX_BINARY" check -c "$work/server.json"
"$SINGBOX_BINARY" check -c "$work/client.json"
mkdir -p "$work/mihomo-home"
"$MIHOMO_BINARY" -t -d "$work/mihomo-home" -f "$work/mihomo.yaml"
AUDIT_ROOT="$root" AUDIT_MODE=nft-setup ip netns exec "$srv" "$bin_dir/helper"
ip netns exec "$srv" python3 -m http.server 18080 --bind 127.0.0.1 --directory "$work" > "$work/origin.log" 2>&1 &
ip netns exec "$srv" "$SINGBOX_BINARY" run -c "$work/server.json" > "$work/server.log" 2>&1 &
ip netns exec "$cli" "$SINGBOX_BINARY" run -c "$work/client.json" > "$work/client.log" 2>&1 &
ip netns exec "$cli" "$MIHOMO_BINARY" -d "$work/mihomo-home" -f "$work/mihomo.yaml" > "$work/mihomo.log" 2>&1 &
sleep 1
printf 'iteration,singbox,mihomo\n' > "$a/evidence/hy2-requests.csv"
: > "$a/evidence/hy2-sockets.txt"
for i in $(seq 1 24);do
 sb=$(ip netns exec "$cli" curl --noproxy '' --socks5-hostname 127.0.0.1:19080 --max-time 4 -s -o /dev/null -w '%{http_code}' http://127.0.0.1:18080/ || true)
 mh=$(ip netns exec "$cli" curl --noproxy '' --socks5-hostname 127.0.0.1:19081 --max-time 4 -s -o /dev/null -w '%{http_code}' http://127.0.0.1:18080/ || true)
 printf '%s,%s,%s\n' "$i" "$sb" "$mh" >> "$a/evidence/hy2-requests.csv"
 ip netns exec "$cli" ss -uan >> "$a/evidence/hy2-sockets.txt"
 sleep 5
done
awk -F, 'NR>1{if($2==200)s++;if($3==200)m++;n++}END{printf "HY2 sing-box=%d/%d mihomo=%d/%d\n",s,n,m,n}' "$a/evidence/hy2-requests.csv"
printf 'OBSERVED_HOP_PORTS '
grep -oE '172\.30\.195\.1:200[0-9]+' "$a/evidence/hy2-sockets.txt" | sort -u | tr '\n' ' '
printf '\n'
ip netns exec "$srv" nft list table inet proxy_agent_hop
