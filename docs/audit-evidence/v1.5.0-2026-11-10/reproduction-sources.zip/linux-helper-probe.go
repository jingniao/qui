package main
import("context";"encoding/json";"fmt";"os";"os/exec";"path/filepath";"strings";"proxycontrol/internal/agent/tuning";"proxycontrol/internal/agent/hostnet")
func main(){os.Exit(run())}
func run()int{
 self,_:=os.Readlink("/proc/self/ns/net");host,_:=os.Readlink("/proc/1/ns/net")
 if self==host||self==""{fmt.Println("REFUSE: must run in separate network namespace");return 2}
 root:=os.Getenv("AUDIT_ROOT");if !strings.HasPrefix(root,"/run/qui-audit-v150-"){return 2}
 mode:=os.Getenv("AUDIT_MODE")
 if mode=="nft"||mode=="nft-setup"{
  d:=hostnet.Desired{ID:"audit-hop",PortHops:[]hostnet.PortHop{{Start:20000,End:20010,Target:8443}}}
  err:=hostnet.Apply(context.Background(),d,hostnet.HostInterfaceLookup,hostnet.RunNft)
  fmt.Printf("nft_apply_error=%v\n",err);if err!=nil{return 3}
  b,err:=exec.Command("/usr/sbin/nft","list","table","inet",hostnet.HopTable).CombinedOutput();fmt.Printf("nft_table=%s error=%v\n",b,err)
  if mode=="nft-setup"{return 0}
  err=hostnet.Apply(context.Background(),hostnet.Desired{ID:"audit-clear"},hostnet.HostInterfaceLookup,hostnet.RunNft);fmt.Printf("nft_clear_error=%v\n",err);if err!=nil{return 3}
  b,err=exec.Command("/usr/sbin/nft","list","table","inet",hostnet.HopTable).CombinedOutput();fmt.Printf("nft_absent_after_clear=%v\n",err!=nil);if err==nil{return 3};return 0
 }
 dir,err:=os.MkdirTemp(root,"config-");if err!=nil{fmt.Println(err);return 2}
 h:=tuning.Helper{ProcRoot:"/proc/sys",ConfigDir:dir}
 before:=tuning.Current("/proc/sys")
 settings:=map[string]string{"net.ipv4.tcp_slow_start_after_idle":"0","net.ipv4.tcp_notsent_lowat":"131072","net.ipv4.udp_rmem_min":"8192","net.ipv4.udp_wmem_min":"8192","net.ipv4.tcp_rmem":"8388608"}
 if mode=="bbr"{settings=map[string]string{"net.ipv4.tcp_congestion_control":"bbr"}}
 result:=h.Apply(tuning.Desired{RequestID:"audit-apply",Settings:settings});raw,_:=json.Marshal(result);fmt.Printf("apply_result=%s\n",raw)
 config,configErr:=os.ReadFile(filepath.Join(dir,tuning.ConfigName));fmt.Printf("persisted=%v\n",configErr==nil&&len(config)>0)
 clear:=h.Apply(tuning.Desired{RequestID:"audit-clear",Clear:true});fmt.Printf("clear_status=%s\n",clear.Status)
 after:=tuning.Current("/proc/sys");restored:=true;for k:=range settings{if before[k]!=after[k]{restored=false}}
 fmt.Printf("namespace_values_restored=%v\n",restored)
 if result.Status!="applied"||clear.Status!="cleared"||!restored{return 10};return 0
}
