#!/usr/bin/env bash
set -euo pipefail
a=/root/qui-audit/20261110-0b60eca
root=$(mktemp -d /run/qui-audit-v150-XXXXXX)
bin_dir=$(mktemp -d /usr/local/lib/qui-audit-v150-XXXXXX)
unit=qui-audit-v150-$$.service
ns_pid=''
cleanup(){
 set +e
 systemctl stop "$unit" >/dev/null 2>&1
 rm -f "/run/systemd/system/$unit"
 systemctl daemon-reload
 systemctl reset-failed "$unit" >/dev/null 2>&1
 if [[ -n $ns_pid ]];then kill "$ns_pid" 2>/dev/null;wait "$ns_pid" 2>/dev/null;fi
 [[ $root == /run/qui-audit-v150-* ]] && rm -rf -- "$root"
 [[ $bin_dir == /usr/local/lib/qui-audit-v150-* ]] && rm -rf -- "$bin_dir"
}
trap cleanup EXIT
cd "$a/probe-src"
. /root/qui-env.sh
go build -o "$bin_dir/probe" ./.tools/linux-helper-probe.go
for log in helper-sandbox helper-sandbox-expanded helper-sandbox-bbr; do : > "$a/evidence/$log.log"; done
unshare -n -- sleep 600 & ns_pid=$!
sleep 0.2
printf 'NAMESPACE %s\n' "$(readlink /proc/$ns_pid/ns/net)"
export AUDIT_ROOT="$root" AUDIT_MODE=tuning
set +e
nsenter -t "$ns_pid" -n "$bin_dir/probe" > "$a/evidence/helper-root.log" 2>&1
printf 'root_tuning_exit=%s\n' "$?"
AUDIT_MODE=nft nsenter -t "$ns_pid" -n "$bin_dir/probe" > "$a/evidence/helper-nft.log" 2>&1
printf 'namespace_nft_exit=%s\n' "$?"
set -e
sed -e "s|^ExecStart=.*|ExecStart=$bin_dir/probe|" -e '/^\[Install\]/,$d' deploy/systemd/proxy-agent-tuning.service > "/run/systemd/system/$unit"
cat >> "/run/systemd/system/$unit" <<EOF
NetworkNamespacePath=/proc/$ns_pid/ns/net
ReadWritePaths=$root
Environment=AUDIT_ROOT=$root AUDIT_MODE=tuning
StandardOutput=append:$a/evidence/helper-sandbox.log
StandardError=append:$a/evidence/helper-sandbox.log
EOF
systemctl daemon-reload
set +e
systemctl start "$unit" >/dev/null 2>&1
printf 'packaged_sandbox_tuning_exit=%s\n' "$?"
set -e
cat >> "/run/systemd/system/$unit" <<EOF
ReadWritePaths=-/proc/sys/net/ipv4/tcp_slow_start_after_idle -/proc/sys/net/ipv4/tcp_notsent_lowat
ReadWritePaths=-/proc/sys/net/core/rmem_default -/proc/sys/net/core/wmem_default
ReadWritePaths=-/proc/sys/net/ipv4/udp_rmem_min -/proc/sys/net/ipv4/udp_wmem_min
StandardOutput=append:$a/evidence/helper-sandbox-expanded.log
StandardError=append:$a/evidence/helper-sandbox-expanded.log
EOF
systemctl daemon-reload
set +e
systemctl start "$unit" >/dev/null 2>&1
printf 'expanded_sandbox_tuning_exit=%s\n' "$?"
set -e
printf 'BBR_MODULE_BEFORE ';test -d /sys/module/tcp_bbr && echo loaded || echo not-loaded
cat >> "/run/systemd/system/$unit" <<EOF
Environment=AUDIT_MODE=bbr
StandardOutput=append:$a/evidence/helper-sandbox-bbr.log
StandardError=append:$a/evidence/helper-sandbox-bbr.log
EOF
systemctl daemon-reload
set +e
systemctl start "$unit" >/dev/null 2>&1
printf 'sandbox_bbr_exit=%s\n' "$?"
set -e
printf 'BBR_MODULE_AFTER ';test -d /sys/module/tcp_bbr && echo loaded || echo not-loaded
cat "$a/evidence/helper-root.log" "$a/evidence/helper-nft.log" "$a/evidence/helper-sandbox.log" "$a/evidence/helper-sandbox-expanded.log" "$a/evidence/helper-sandbox-bbr.log"
