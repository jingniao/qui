#!/usr/bin/env bash
set -euo pipefail
a=/root/qui-audit/20261110-0b60eca
mkdir -p "$a/bin" "$a/live"
cd "$a/src"
go build -trimpath -ldflags '-X main.version=1.5.0-audit' -o "$a/bin/proxy-panel" ./cmd/panel
cat > "$a/live/panel.yaml" <<EOF
development: true
http_address: 127.0.0.1:22950
grpc_address: 127.0.0.1:22951
database: $a/live/panel.db
node_identity_directory: $a/live/identity
shutdown_timeout: 5s
EOF
chmod 0600 "$a/live/panel.yaml"
setsid "$a/bin/proxy-panel" --config "$a/live/panel.yaml" > "$a/live/panel.log" 2>&1 < /dev/null &
echo $! > "$a/live/panel.pid"
for i in $(seq 1 40); do
  if curl -fsS http://127.0.0.1:22950/api/v1/auth/session >/dev/null; then
    printf 'ISOLATED_PANEL_READY pid=%s\n' "$(cat "$a/live/panel.pid")"
    exit 0
  fi
  sleep 0.25
done
echo ISOLATED_PANEL_FAILED
exit 1
