#!/usr/bin/env bash
set -euo pipefail
"$HOME/.qui-local/r.sh" 'a=/root/qui-audit/20261110-0b60eca/evidence; cat "$a/runner.log"; printf "CHECK TAIL\n"; tail -n 8 "$a/check.log" 2>/dev/null; printf "CORES TAIL\n"; tail -n 6 "$a/cores.log" 2>/dev/null; ps -eo pid,etimes,comm,args | grep -E "qui-audit|go test -race|ci-real-core" | grep -v grep'
