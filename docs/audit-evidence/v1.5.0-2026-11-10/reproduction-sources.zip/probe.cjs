const fs = require('node:fs');
const path = require('node:path');
const ts = require(path.resolve('web/node_modules/typescript'));
const YAML = require(path.resolve('web/node_modules/yaml'));
(async () => {
  const doc = YAML.parseDocument(fs.readFileSync('.github/workflows/check.yml', 'utf8'));
  console.log('workflow_yaml_errors:', doc.errors.map(e => e.message.split('\n')[0]));
  const source = fs.readFileSync('web/src/modules/nodes/components/detail/serverTuningModel.ts', 'utf8');
  const code = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.ESNext } }).outputText;
  const m = await import('data:text/javascript;base64,' + Buffer.from(code).toString('base64'));
  const key = 'net.ipv4.tcp_rmem';
  const state = {current:{[key]:'4096 131072 8388608'},desired:{[key]:'8388608'}};
  console.log('satisfied_tcp_rmem_status:', m.keyStatus(key, state, {}));
  const external = {current:state.current,desired:{}};
  const host = {sysctlSources:[{key,file:'99-bbr.conf',value:state.current[key]}]};
  const draft = m.adoptExternal({}, external, host);
  try { console.log('adopt_external_request:', m.tuningRequest('audit',draft)); }
  catch (e) { console.log('adopt_external_request_error:',e.message); }
  const bbr3 = {congestionAvailable:['bbr3']};
  console.log('bbr3_options:',m.algorithmOptions('cc',bbr3));
  try { console.log('bbr3_request:',m.tuningRequest('audit',{'net.ipv4.tcp_congestion_control':'bbr3'})); }
  catch (e) { console.log('bbr3_request_error:',e.message); }
  console.log('readonly_key_status:',m.keyStatus('net.core.rmem_max',{current:{'net.core.rmem_max':'212992'},desired:{}},{tuningKeys:[{key:'net.core.rmem_max',present:true,writable:false}]}));
})();
