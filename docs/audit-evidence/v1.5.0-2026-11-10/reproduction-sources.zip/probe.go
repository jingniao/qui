package main

import (
 "context"
 "fmt"
 "os"
 "path/filepath"
 "time"
 "proxycontrol/internal/panel/policy"
 "proxycontrol/internal/panel/notification"
 "proxycontrol/internal/platform/db"
 "proxycontrol/internal/platform/vault"
)

type fetcher struct{}
func (fetcher) Fetch(context.Context,string)([]byte,error){return []byte("DOMAIN,old.example.com\n"),nil}
func must(err error){if err!=nil{panic(err)}}
func main(){
 ctx:=context.Background()
 dir,err:=os.MkdirTemp(".tools/v150-audit","probe-");must(err)
 database,err:=db.Open(ctx,filepath.Join(dir,"panel.db"));must(err);defer database.Close()
 v,err:=vault.Open(filepath.Join(dir,"configuration.key"));must(err)
 repo:=&policy.Repository{Database:database}
 svc,err:=repo.SaveService(ctx,"",policy.ServiceInput{Name:"audit",Enabled:true,Domains:[]string{"manual.example.com"}});must(err)
 src:=policy.SourceInput{ID:"audit-source",URL:"https://old.example.com/rules",Format:"text",Behavior:"classical",IntervalSeconds:86400}
 must(repo.SaveSources(ctx,nil,svc.ID,[]policy.SourceInput{src}))
 refresher:=&policy.SourceRefresher{Repository:repo,Vault:v,Fetcher:fetcher{}}
 result,err:=refresher.Refresh(ctx,src.ID);must(err)
 fmt.Printf("server_wiring_refresh: status=%s entries=%d\n",result.LastStatus,result.EntryCount)
 _,err=repo.SourceEntries(ctx,svc.ID)
 fmt.Printf("server_wiring_read_cache_error: %v\n",err)
 repo.Vault=v
 src.URL="https://new.example.com/rules"
 must(repo.SaveSources(ctx,nil,svc.ID,[]policy.SourceInput{src}))
 got,err:=repo.Service(ctx,svc.ID);must(err)
 entries,err:=repo.SourceEntries(ctx,svc.ID);must(err)
 fmt.Printf("changed_url: url=%s status=%s cached_domains=%v\n",got.Sources[0].URL,got.Sources[0].LastStatus,entries.Domains)
 now:=time.Now().UTC()
 rule:=[]notification.Rule{{Kind:"public_ip",Enabled:true,CooldownMinutes:30}}
 snap:=notification.Snapshot{Now:now,Nodes:[]notification.NodeSnapshot{{ID:"n",Name:"audit",Status:"online",Addresses:[]string{"8.8.8.8"}}}}
 _,states:=notification.Evaluate(rule,snap,nil)
 snap.Now=now.Add(time.Minute);snap.Nodes[0].Addresses=[]string{"1.1.1.1"}
 first,states:=notification.Evaluate(rule,snap,states)
 snap.Now=now.Add(2*time.Minute);snap.Nodes[0].Addresses=[]string{"9.9.9.9"}
 second,states:=notification.Evaluate(rule,snap,states)
 snap.Now=now.Add(3*time.Minute);snap.Nodes[0].Addresses=nil
 removed,_:=notification.Evaluate(rule,snap,states)
 fmt.Printf("ip_notifications: first=%d second_within_cooldown=%d last_address_removed=%d\n",len(first),len(second),len(removed))
 nr:=&notification.Repository{Database:database,Vault:v}
 active:=notification.State{Key:"node_offline:n",Active:true,Since:now.Add(-time.Hour),LastNotified:now.Add(-time.Minute)}
 must(nr.SaveState(ctx,active))
 persisted,err:=nr.States(ctx);must(err)
 offlineRule:=[]notification.Rule{{Kind:"node_offline",Enabled:true,DurationMinutes:3,CooldownMinutes:30}}
 recovered:=notification.Snapshot{Now:now,Nodes:[]notification.NodeSnapshot{{ID:"n",Name:"audit",Status:"online",LastHeartbeat:now}}}
 recovery1,next:=notification.Evaluate(offlineRule,recovered,persisted)
 must(nr.SaveStates(ctx,next))
 persisted,err=nr.States(ctx);must(err)
 recovery2,_:=notification.Evaluate(offlineRule,recovered,persisted)
 fmt.Printf("recovery_persistence: first=%d next_has_key=%v persisted_active=%v repeated_recovery=%d\n",len(recovery1),next[active.Key].Active,persisted[active.Key].Active,len(recovery2))
}
