#!/usr/bin/env bash
set -euo pipefail
"$HOME/.qui-local/r.sh" 'hostname; date -u +%FT%TZ; uname -srmo; uptime; df -h /root; free -m; systemctl is-active proxy-panel proxy-agent proxy-agent-host-network.path proxy-agent-tuning.path 2>/dev/null; ps -eo pid,etimes,comm,args | grep -E "qui-gate|scripts/check|go test|proxy-panel|proxy-agent" | grep -v grep; test ! -e /root/qui-env.sh || sed -n "1,45p" /root/qui-env.sh'
