#!/usr/bin/env bash
set -euo pipefail
r="$HOME/.qui-local/r.sh"
a=/root/qui-audit/20261110-0b60eca
"$r" "cat > $a/cleanup-live.sh" < .tools/v150-audit/cleanup-live.sh
"$r" "bash $a/cleanup-live.sh"
