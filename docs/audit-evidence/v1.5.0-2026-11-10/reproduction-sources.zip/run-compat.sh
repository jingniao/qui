#!/usr/bin/env bash
set -euo pipefail
r="$HOME/.qui-local/r.sh"
a=/root/qui-audit/20261110-0b60eca
"$r" "mkdir -p $a/legacy-src"
git archive --format=tar 25b95e3 | "$r" "tar -xf - -C $a/legacy-src"
"$r" "cat > $a/probe-src/.tools/compat-generate.go" < .tools/v150-audit/compat-generate.go
"$r" "mkdir -p $a/legacy-src/.tools; cat > $a/legacy-src/.tools/compat-decode.go" < .tools/v150-audit/compat-decode.go
"$r" "cd $a/probe-src && . /root/qui-env.sh && go run ./.tools/compat-generate.go $a/evidence > $a/evidence/old-agent-compat.log 2>&1; code=\$?; if test \$code -eq 0;then cd $a/legacy-src; go run ./.tools/compat-decode.go $a/evidence >> $a/evidence/old-agent-compat.log 2>&1; code=\$?;fi; echo \$code > $a/evidence/old-agent-compat.exit; cat $a/evidence/old-agent-compat.log"
