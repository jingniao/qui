#!/usr/bin/env bash
set -euo pipefail
r="$HOME/.qui-local/r.sh"
a=/root/qui-audit/20261110-0b60eca
"$r" "cat > $a/probe-src/internal/panel/policy/audit_parse_fuzz_test.go" < .tools/v150-audit/audit_parse_fuzz_test.go
"$r" "cat > $a/cross-fuzz.sh" < .tools/v150-audit/cross-fuzz.sh
"$r" "setsid bash $a/cross-fuzz.sh > $a/evidence/cross-fuzz-runner.log 2>&1 < /dev/null & sleep 1; echo CROSS_FUZZ_STARTED"
