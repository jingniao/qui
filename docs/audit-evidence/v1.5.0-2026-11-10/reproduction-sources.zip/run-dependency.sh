#!/usr/bin/env bash
set -euo pipefail
r="$HOME/.qui-local/r.sh"
a=/root/qui-audit/20261110-0b60eca
"$r" "cat > $a/dependency-audit.sh" < .tools/v150-audit/dependency-audit.sh
"$r" "setsid bash $a/dependency-audit.sh > $a/evidence/dependency-runner.log 2>&1 < /dev/null & sleep 1; echo DEPENDENCY_AUDIT_STARTED"
