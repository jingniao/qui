#!/usr/bin/env bash
set -euo pipefail
r="$HOME/.qui-local/r.sh"
a=/root/qui-audit/20261110-0b60eca
"$r" "cat > $a/probe-src/.tools/linux-helper-probe.go" < .tools/v150-audit/linux-helper-probe.go
"$r" "cat > $a/hy2-test.sh" < .tools/v150-audit/hy2-test.sh
"$r" "setsid bash -c 'bash $a/hy2-test.sh > $a/evidence/hy2.log 2>&1; echo \$? > $a/evidence/hy2.exit' < /dev/null > /dev/null 2>&1 & sleep 1; tail -n 4 $a/evidence/hy2.log"
