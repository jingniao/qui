#!/usr/bin/env bash
set -euo pipefail
r="$HOME/.qui-local/r.sh"
a=/root/qui-audit/20261110-0b60eca
"$r" "mkdir -p $a/probe-src/.tools"
"$r" "cat > $a/probe-src/.tools/linux-helper-probe.go" < .tools/v150-audit/linux-helper-probe.go
"$r" "cat > $a/linux-helper-test.sh" < .tools/v150-audit/linux-helper-test.sh
"$r" "bash $a/linux-helper-test.sh > $a/evidence/helper-summary.log 2>&1; result=\$?; echo \$result > $a/evidence/helper-summary.exit; cat $a/evidence/helper-summary.log"
