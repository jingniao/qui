#!/usr/bin/env bash
set -euo pipefail
r="$HOME/.qui-local/r.sh"
a=/root/qui-audit/20261110-0b60eca
"$r" "mkdir -p $a/probe-src"
git archive --format=tar 0b60eca | "$r" "tar -xf - -C $a/probe-src"
"$r" "cat > $a/probe-src/internal/panel/system/backup/audit_regression_test.go" < .tools/v150-audit/audit_backup_test.go
"$r" "cat > $a/probe-src/internal/panel/deployment/audit_regression_test.go" < .tools/v150-audit/audit_release_test.go
"$r" "cd $a/probe-src && . /root/qui-env.sh && go test -count=1 -p 1 -run '^TestAudit' -v ./internal/panel/system/backup ./internal/panel/deployment > $a/evidence/audit-overlays.log 2>&1; echo \$? > $a/evidence/audit-overlays.exit; cat $a/evidence/audit-overlays.log"
