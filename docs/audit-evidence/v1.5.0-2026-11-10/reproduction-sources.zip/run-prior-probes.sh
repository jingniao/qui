#!/usr/bin/env bash
set -euo pipefail
r="$HOME/.qui-local/r.sh"
a=/root/qui-audit/20261110-0b60eca
"$r" "mkdir -p $a/probe-src/.tools/v150-audit"
"$r" "cat > $a/probe-src/.tools/v150-audit/probe.go" < .tools/v150-audit/probe.go
"$r" "cd $a/probe-src && . /root/qui-env.sh && go run ./.tools/v150-audit/probe.go > $a/evidence/prior-probes-linux.log 2>&1; echo \$? > $a/evidence/prior-probes-linux.exit; cat $a/evidence/prior-probes-linux.log"
