import sqlite3,json,sys,datetime
a='/root/qui-audit/20261110-0b60eca'
ids=json.load(sys.stdin)
now=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='microseconds').replace('+00:00','Z')
db=sqlite3.connect(a+'/live/panel.db',timeout=20)
keys=['net.ipv4.tcp_congestion_control','net.core.default_qdisc','net.ipv4.tcp_slow_start_after_idle','net.ipv4.tcp_notsent_lowat','net.ipv4.tcp_rmem','net.ipv4.tcp_wmem','net.core.rmem_max','net.core.wmem_max','net.ipv4.tcp_mtu_probing','fs.file-max','net.core.somaxconn','net.ipv4.tcp_max_syn_backlog','net.ipv4.tcp_fastopen','net.ipv4.tcp_ecn','net.ipv4.tcp_tw_reuse','net.core.rmem_default','net.core.wmem_default','net.ipv4.udp_rmem_min','net.ipv4.udp_wmem_min']
current={'net.ipv4.tcp_congestion_control':'cubic','net.core.default_qdisc':'fq','net.ipv4.tcp_rmem':'4096 131072 8388608','net.ipv4.tcp_wmem':'4096 16384 8388608','net.core.rmem_max':'212992','net.core.wmem_max':'212992','net.ipv4.tcp_slow_start_after_idle':'1','net.ipv4.tcp_notsent_lowat':'4294967295','net.ipv4.tcp_mtu_probing':'0'}
caps={'coreName':'xray','coreVersion':'26.3.27','tuningSupported':True,'host':{'virtualization':'kvm','cpuCores':2,'memoryTotalBytes':'2147483648','congestionAvailable':['cubic','reno'],'congestionLoadable':['bbr'],'qdiscAvailable':['fq','pfifo_fast'],'qdiscLoadable':['cake'],'tuningKeys':[{'key':k,'present':True,'writable':k!='net.core.rmem_max'} for k in keys],'fdLimits':[{'name':'proxy-agent','soft':'524287','hard':'524287'},{'name':'xray','soft':'524287','hard':'524287'}],'sysctlSources':[{'key':'net.core.default_qdisc','file':'50-audit.conf','value':'fq'},{'key':'net.ipv4.tcp_wmem','file':'50-audit.conf','value':current['net.ipv4.tcp_wmem']}]},'protocols':[{'protocol':'http','inbound':True,'outbound':True,'tcp':True}]}
hb={'bootId':'audit-same-boot','coreHealthy':True,'tuningCurrent':current}
addresses=[{'address':'8.8.8.8','family':'ipv4','source':'interface:audit0','lastSeen':now},{'address':'9.9.9.9','family':'ipv4','source':'peer','lastSeen':now}]
db.execute("UPDATE nodes SET status='online',last_heartbeat=?,agent_version='1.5.0-audit',hostname='audit-fixture',operating_system='linux',capabilities_json=?,heartbeat_json=?,public_ip='8.8.8.8',public_ip_selected='8.8.8.8',public_addresses_json=? WHERE id=?",(now,json.dumps(caps),json.dumps(hb),json.dumps(addresses),ids['nodeId']))
desired={'net.ipv4.tcp_rmem':'8388608','net.ipv4.tcp_congestion_control':'cubic'}
result={'requestId':'audit-fixture-request','status':'applied','keys':[],'initial':{'net.ipv4.tcp_rmem':'4096 131072 6291456','net.ipv4.tcp_congestion_control':'cubic'}}
db.execute("INSERT INTO node_tuning(node_id,desired_json,request_id,status,result_json,requested_at,updated_at) VALUES(?,?,?,'applied',?,?,?) ON CONFLICT(node_id) DO UPDATE SET desired_json=excluded.desired_json,status='applied',result_json=excluded.result_json",(ids['nodeId'],json.dumps(desired),'audit-fixture-request',json.dumps(result),now,now))
for kind,title in [('cpu','AUDIT CPU visible to Viewer'),('system_alert','AUDIT system alert Owner only')]:
 db.execute("INSERT INTO notifications(at,kind,severity,node_id,title,body) VALUES(?,?,'warning',?,?,?)",(now,kind,ids['nodeId'],title,'audit fixture'))
db.commit()
blobs=db.execute("SELECT encrypted_config FROM notification_channels WHERE name='Audit disabled channel'").fetchall()
print(json.dumps({'fixture_node_updated':True,'channels':len(blobs),'channel_secret_found_in_ciphertext':any(b'AUDIT_ONLY_SECRET_1234' in b[0] for b in blobs)}))
db.close()
