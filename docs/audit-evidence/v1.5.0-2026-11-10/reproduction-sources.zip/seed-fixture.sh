#!/usr/bin/env bash
set -euo pipefail
r="$HOME/.qui-local/r.sh"
a=/root/qui-audit/20261110-0b60eca
"$r" "cat > $a/seed-fixture.py" < .tools/v150-audit/seed-fixture.py
node -e 'const fs=require("fs"),s=JSON.parse(fs.readFileSync(".tools/v150-audit/evidence/sessions.private.json"));fs.writeFileSync(".tools/v150-audit/evidence/fixture-public.json",JSON.stringify({nodeId:s.nodeId,serviceId:s.serviceId}));'
"$r" "python3 $a/seed-fixture.py" < .tools/v150-audit/evidence/fixture-public.json
