#!/usr/bin/env bash
set -euo pipefail
r="$HOME/.qui-local/r.sh"
audit=/root/qui-audit/20261110-0b60eca
"$r" "test ! -e $audit && mkdir -p $audit/src $audit/evidence"
git archive --format=tar 0b60eca7b3c57f72a8ddd7c1b6a86eafb95940eb | "$r" "tar -xf - -C $audit/src"
"$r" "cat > $audit/run.sh" < .tools/v150-audit/full-run.sh
"$r" "(date -u +%FT%TZ; nproc; command -v go node npm nft unshare; systemctl is-active proxy-panel proxy-agent proxy-agent-host-network.path proxy-agent-tuning.path; nft list tables; sysctl net.ipv4.tcp_congestion_control net.core.default_qdisc; sha256sum /etc/sysctl.d/99-proxy-tuning.conf /var/lib/proxy-agent/tuning/desired.json /var/lib/proxy-agent/host-network/desired.json 2>/dev/null) > $audit/evidence/baseline.txt; setsid bash $audit/run.sh > $audit/evidence/runner.log 2>&1 < /dev/null & sleep 1; cat $audit/evidence/runner.log"
