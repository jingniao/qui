#!/usr/bin/env bash
set -euo pipefail
export SSH_ASKPASS="$HOME/.qui-local/askpass.sh" SSH_ASKPASS_REQUIRE=force DISPLAY=x
exec ssh -N -o ExitOnForwardFailure=yes -o StrictHostKeyChecking=accept-new -o UserKnownHostsFile="$HOME/.qui-local/known_hosts" -o ConnectTimeout=10 -o PubkeyAuthentication=no -o PreferredAuthentications=password,keyboard-interactive -L 127.0.0.1:18195:127.0.0.1:22950 root@192.168.5.36
