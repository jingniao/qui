#!/usr/bin/env bash
set -euo pipefail
r="$HOME/.qui-local/r.sh"
"$r" 'cat > /root/qui-audit/20261110-0b60eca/panel-start.sh' < .tools/v150-audit/panel-start.sh
"$r" 'bash /root/qui-audit/20261110-0b60eca/panel-start.sh'
